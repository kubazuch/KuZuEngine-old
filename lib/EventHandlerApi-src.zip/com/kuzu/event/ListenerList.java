package com.kuzu.event;

import com.kuzu.event.api.EventPriority;
import com.kuzu.event.api.IEventListener;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicReference;

public class ListenerList {
	private static List<ListenerList> allLists = new ArrayList<>();
	private static int maxSize = 0;

	@Nullable
	private ListenerList parent;
	private ListenerListInst[] lists = new ListenerListInst[0];

	public ListenerList() {
		this(null);
	}

	public ListenerList(@Nullable ListenerList parent) {
		this.parent = parent;
		extendMasterList(this);
		resizeLists(maxSize);
	}

	private synchronized static void extendMasterList(ListenerList inst) {
		allLists.add(inst);
	}

	public static void resize(int max) {
		if (max <= maxSize) {
			return;
		}

		synchronized (ListenerList.class) {
			allLists.forEach(list -> list.resizeLists(max));
		}

		maxSize = max;
	}

	public static synchronized void clearBusID(int id) {
		for (ListenerList list : allLists)
			list.lists[id].dispose();
	}

	public static synchronized void unregisterAll(int id, IEventListener listener) {
		for (ListenerList list : allLists) {
			list.unregister(id, listener);
		}
	}

	public synchronized void resizeLists(int max) {
		if (parent != null) {
			parent.resizeLists(max);
		}

		if (lists.length >= max) {
			return;
		}

		ListenerListInst[] newList = new ListenerListInst[max];
		int x = 0;
		for (; x < lists.length; x++) {
			newList[x] = lists[x];
		}

		for (; x < max; x++) {
			if (parent != null) {
				newList[x] = new ListenerListInst(parent.getInstance(x));
			} else {
				newList[x] = new ListenerListInst();
			}
		}

		lists = newList;
	}

	protected ListenerListInst getInstance(int id) {
		return lists[id];
	}

	public IEventListener[] getListeners(int id) {
		return lists[id].getListeners();
	}

	public void register(int id, EventPriority priority, IEventListener listener) {
		lists[id].register(priority, listener);
	}

	public void unregister(int id, IEventListener listener) {
		lists[id].unregister(listener);
	}

	private class ListenerListInst {
		private boolean rebuild = true;
		private AtomicReference<IEventListener[]> listeners = new AtomicReference<>();
		private ArrayList<ArrayList<IEventListener>> priorities;
		private ListenerListInst parent;
		private List<ListenerListInst> children;
		private Semaphore writeLock = new Semaphore(1, true);

		private ListenerListInst() {
			int count = EventPriority.values().length;
			priorities = new ArrayList<>(count);

			for (int x = 0; x < count; x++) {
				priorities.add(new ArrayList<>());
			}
		}

		private ListenerListInst(ListenerListInst parent) {
			this();
			this.parent = parent;
			this.parent.addChild(this);
		}

		public void dispose() {
			writeLock.acquireUninterruptibly();
			priorities.forEach(ArrayList::clear);
			priorities.clear();
			writeLock.release();
			parent = null;
			listeners = null;
			if (children != null)
				children.clear();
		}

		public ArrayList<IEventListener> getListeners(EventPriority priority) {
			writeLock.acquireUninterruptibly();
			ArrayList<IEventListener> ret = new ArrayList<>(priorities.get(priority.ordinal()));
			writeLock.release();
			if (parent != null) {
				ret.addAll(parent.getListeners(priority));
			}

			return ret;
		}

		public IEventListener[] getListeners() {
			if (shouldRebuild()) buildCache();
			return listeners.get();
		}

		protected boolean shouldRebuild() {
			return rebuild;
		}

		protected void forceRebuild() {
			this.rebuild = true;
			if (this.children != null) {
				for (ListenerListInst child : this.children) {
					child.forceRebuild();
				}
			}
		}

		private void addChild(ListenerListInst child) {
			if (this.children == null) {
				this.children = new ArrayList<>();
			}

			this.children.add(child);
		}

		private void buildCache() {
			if (parent != null && parent.shouldRebuild()) {
				parent.buildCache();
			}

			ArrayList<IEventListener> ret = new ArrayList<>();
			Arrays.stream(EventPriority.values()).forEach(value -> {
				List<IEventListener> listeners = getListeners(value);
				if (listeners.size() > 0) {
					ret.add(value);
					ret.addAll(listeners);
				}
			});

			this.listeners.set(ret.toArray(new IEventListener[0]));
			rebuild = false;
		}

		public void register(EventPriority priority, IEventListener listener) {
			writeLock.acquireUninterruptibly();
			priorities.get(priority.ordinal()).add(listener);
			writeLock.release();
			forceRebuild();
		}

		public void unregister(IEventListener listener) {
			writeLock.acquireUninterruptibly();
			priorities.stream().filter(list -> list.remove(listener)).forEach(list -> this.forceRebuild());
			writeLock.release();
		}
	}
}
