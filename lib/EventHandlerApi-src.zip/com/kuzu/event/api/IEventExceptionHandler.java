package com.kuzu.event.api;

import com.kuzu.event.EventBus;

public interface IEventExceptionHandler {
	void handleException(EventBus bus, Event event, IEventListener[] listeners, int index, Throwable throwable);
}
