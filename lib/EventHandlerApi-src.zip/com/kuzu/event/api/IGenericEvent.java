package com.kuzu.event.api;

import java.lang.reflect.Type;

public interface IGenericEvent<T> {
	Type getGenericType();
}
