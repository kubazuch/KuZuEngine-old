package com.kuzu.event.api;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Retention(value = RUNTIME)
@Target(value = METHOD)
public @interface EventSubscriber {
	EventPriority priority() default EventPriority.NORMAL;

	boolean receiveCanceled() default false;
}
