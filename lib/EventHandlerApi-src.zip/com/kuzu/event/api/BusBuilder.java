package com.kuzu.event.api;

import com.kuzu.event.EventBus;

public class BusBuilder {
	private IEventExceptionHandler exceptionHandler;

	private boolean trackPhases = true;
	private boolean startShutdown = false;

	public static BusBuilder builder() {
		return new BusBuilder();
	}

	public BusBuilder startShutdown() {
		this.startShutdown = true;
		return this;
	}

	public IEventExceptionHandler getExceptionHandler() {
		return exceptionHandler;
	}

	public BusBuilder setExceptionHandler(IEventExceptionHandler handler) {
		this.exceptionHandler = handler;
		return this;
	}

	public boolean getTrackPhases() {
		return trackPhases;
	}

	public BusBuilder setTrackPhases(boolean trackPhases) {
		this.trackPhases = trackPhases;
		return this;
	}

	public boolean isStartingShutdown() {
		return startShutdown;
	}

	public IEventBus build() {
		return new EventBus(this);
	}
}
