package com.kuzu.event.api;

import com.kuzu.event.ListenerList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class Event {

	private boolean isCancelled = false;
	private Result result = Result.DEFAULT;
	private EventPriority phase = null;

	public boolean isCancellable() {
		return false;
	}

	public boolean isCancelled() {
		return isCancelled;
	}

	public void setCancelled(boolean cancel) {
		if (!isCancellable())
			throw new UnsupportedOperationException(
					"Attempted to cancel a non-cancellable event: "
							+ this.getClass().getCanonicalName()
			);

		isCancelled = cancel;
	}

	public boolean hasResult() {
		return false;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result value) {
		result = value;
	}

	public ListenerList getListenerList() {
		return EventListenerHelper.getListenerListInternal(this.getClass(), true);
	}

	@Nullable
	public EventPriority getPhase() {
		return phase;
	}

	public void setPhase(@NotNull EventPriority value) {
		Objects.requireNonNull(value, "Phase cannot be null!");
		int prev = phase == null ? -1 : phase.ordinal();
		if (prev >= value.ordinal())
			throw new IllegalArgumentException("Cannot set event phase to " + value + " when already " + phase);
		phase = value;
	}

	public enum Result {
		DENY,
		DEFAULT,
		ALLOW
	}
}
