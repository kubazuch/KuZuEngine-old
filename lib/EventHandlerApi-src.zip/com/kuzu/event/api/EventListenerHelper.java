package com.kuzu.event.api;

import com.kuzu.event.ListenerList;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class EventListenerHelper {
	private final static Map<Class<?>, ListenerList> listeners = new IdentityHashMap<>();
	private static ReadWriteLock lock = new ReentrantReadWriteLock(true);

	public static ListenerList getListenerList(Class<?> eventClass) {
		return getListenerListInternal(eventClass, false);
	}

	static ListenerList getListenerListInternal(Class<?> eventClass, boolean fromInstanceCall) {
		final Lock readLock = lock.readLock();
		readLock.lock();
		ListenerList listenerList = listeners.get(eventClass);
		readLock.unlock();
		if (listenerList == null) {
			listenerList = computeListenerList(eventClass, fromInstanceCall);
			final Lock writeLock = lock.writeLock();
			writeLock.lock();
			readLock.lock();
			listeners.putIfAbsent(eventClass, listenerList);
			listenerList = listeners.get(eventClass);
			readLock.unlock();
			writeLock.unlock();
		}

		return listenerList;
	}

	private static ListenerList computeListenerList(Class<?> eventClass, boolean fromInstanceCall) {
		if (eventClass == Event.class)
			return new ListenerList();

		Class<?> superclass = eventClass.getSuperclass();
		ListenerList parentList = getListenerList(superclass);
		return new ListenerList(parentList);
	}
}
