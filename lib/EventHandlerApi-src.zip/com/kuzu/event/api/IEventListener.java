package com.kuzu.event.api;

public interface IEventListener {
	void invoke(Event event);
}
