package com.kuzu.event;

import com.kuzu.event.api.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class ASMEventHandler implements IEventListener {
	private final IEventListener handler;
	private final EventSubscriber subInfo;
	private String readable;
	private java.lang.reflect.Type filter = null;

	public ASMEventHandler(Object target, Method method, boolean isGeneric) throws Exception {
		handler = event -> {
			try {
				method.invoke(target, event);
			} catch (IllegalAccessException | InvocationTargetException e) {
				e.printStackTrace();
			}
		};
		subInfo = method.getAnnotation(EventSubscriber.class);
		readable = "ASM: " + target + " " + methodToString(method) + " " + subInfo.toString().substring(subInfo.toString().indexOf('('));

		if (isGeneric) {
			java.lang.reflect.Type type = method.getGenericParameterTypes()[0];
			if (type instanceof ParameterizedType) {
				filter = ((ParameterizedType) type).getActualTypeArguments()[0];
				if (filter instanceof ParameterizedType) {
					filter = ((ParameterizedType) filter).getRawType();
				}
			}
		}
	}

	@Override
	public void invoke(Event event) {
		if (handler != null) {
			if (!event.isCancellable() || !event.isCancelled() || subInfo.receiveCanceled()) {
				if (filter == null || filter == ((IGenericEvent) event).getGenericType()) {
					handler.invoke(event);
				}
			}
		}
	}

	public EventPriority getPriority() {
		return subInfo.priority();
	}

	@Override
	public String toString() {
		return readable;
	}

	private static String methodToString(final Method method) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(method.getName()).append('(');
		Type[] types = method.getGenericParameterTypes();
		for (int i = 0; i < types.length; i++) {
			stringBuilder.append(types[i].getTypeName());
			if (i < types.length - 1)
				stringBuilder.append(", ");
		}
		stringBuilder.append(')');
		stringBuilder.append(method.getGenericReturnType().getTypeName());

		return stringBuilder.toString();
	}
}

