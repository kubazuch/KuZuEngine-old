package com.kuzu.event;

import com.kuzu.event.api.*;
import net.jodah.typetools.TypeResolver;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class EventBus implements IEventExceptionHandler, IEventBus {
	private static AtomicInteger maxID = new AtomicInteger(0);
	private final boolean trackPhases;
	private final int busID = maxID.getAndIncrement();
	private ConcurrentHashMap<Object, List<IEventListener>> listeners = new ConcurrentHashMap<>();
	private IEventExceptionHandler exceptionHandler;
	private boolean shutdown = false;

	public EventBus() {
		ListenerList.resize(busID + 1);
		this.exceptionHandler = this;
		this.trackPhases = true;
	}

	public EventBus(final IEventExceptionHandler handler, boolean trackPhase, boolean startShutdown) {
		ListenerList.resize(busID + 1);
		if (handler == null) exceptionHandler = this;
		else exceptionHandler = handler;
		this.trackPhases = trackPhase;
		this.shutdown = startShutdown;
	}

	public EventBus(final BusBuilder busBuilder) {
		this(busBuilder.getExceptionHandler(), busBuilder.getTrackPhases(), busBuilder.isStartingShutdown());
	}

	private void registerClass(final Class<?> clazz) {
		Arrays.stream(clazz.getMethods())
				.filter(m -> Modifier.isStatic(m.getModifiers()))
				.filter(m -> m.isAnnotationPresent(EventSubscriber.class))
				.forEach(m -> registerListener(clazz, m, m));
	}

	private Optional<Method> getDeclMethod(final Class<?> clz, final Method in) {
		try {
			return Optional.of(clz.getDeclaredMethod(in.getName(), in.getParameterTypes()));
		} catch (NoSuchMethodException e) {
			return Optional.empty();
		}
	}

	private void registerObject(final Object obj) {
		final HashSet<Class<?>> classes = new HashSet<>();
		typesFor(obj.getClass(), classes);
		Arrays.stream(obj.getClass().getMethods())
				.filter(m -> !Modifier.isStatic(m.getModifiers()))
				.forEach(m -> classes.stream()
						.map(c -> getDeclMethod(c, m))
						.filter(rm -> rm.isPresent() && rm.get().isAnnotationPresent(EventSubscriber.class))
						.findFirst()
						.ifPresent(rm -> registerListener(obj, m, rm.get())));
	}

	private void typesFor(final Class<?> clz, final Set<Class<?>> visited) {
		if (clz.getSuperclass() == null) return;
		typesFor(clz.getSuperclass(), visited);
		Arrays.stream(clz.getInterfaces()).forEach(i -> typesFor(i, visited));
		visited.add(clz);
	}

	public void register(Object target) {
		if (listeners.containsKey(target)) {
			return;
		}

		if (target.getClass() == Class.class) {
			registerClass((Class<?>) target);
		} else {
			registerObject(target);
		}

//		boolean isStatic = target.getClass() == Class.class;
//
//		Set<? extends Class<?>> supers = isStatic ? Sets.newHashSet((Class<?>) target) : TypeToken.of(target.getClass()).getTypes().rawTypes();
//		for(Method method : (isStatic ? (Class<?>)target : target.getClass()).getMethods()) {
//			if(isStatic && !Modifier.isStatic(method.getModifiers()))
//				continue;
//			else if (!isStatic && Modifier.isStatic(method.getModifiers()))
//				continue;
//
//			for(Class<?> cls : supers) {
//				try {
//					Method real = cls.getDeclaredMethod(method.getName(), method.getParameterTypes());
//					if(real.isAnnotationPresent(EventSubscriber.class)){

//						break;
//					}
//				} catch (NoSuchMethodException ignored) { }
//			}
//		}
	}

	private void registerListener(final Object target, final Method method, final Method real) {
		Class<?>[] parameterTypes = method.getParameterTypes();
		if (parameterTypes.length != 1) {
			throw new IllegalArgumentException("Method " + method + " has @EventSubscriber annotation, but requires " +
					parameterTypes.length + " arguments. Event handler methods must require a single argument."
			);
		}

		Class<?> eventType = parameterTypes[0];

		if (!Event.class.isAssignableFrom(eventType)) {
			throw new IllegalArgumentException("Method " + method + " has @EventSubscriber annotation, but takes " +
					"an argument that is not an Event: " + eventType);
		}

		register(eventType, target, real);
	}

	private <T extends Event> Predicate<T> passCancelled(final boolean ignored) {
		return e -> ignored || !e.isCancellable() || !e.isCancelled();
	}

	private <T extends GenericEvent<? extends F>, F> Predicate<T> passGenericFilter(Class<F> type) {
		return e -> e.getGenericType() == type;
	}

	@Override
	public <T extends Event> void addListener(Consumer<T> consumer) {
		addListener(EventPriority.NORMAL, consumer);
	}

	@Override
	public <T extends Event> void addListener(EventPriority priority, Consumer<T> consumer) {
		addListener(priority, false, consumer);
	}

	@Override
	public <T extends Event> void addListener(final EventPriority priority, final boolean receiveCancelled, final Consumer<T> consumer) {
		addListener(priority, passCancelled(receiveCancelled), consumer);
	}

	@Override
	public <T extends Event> void addListener(EventPriority priority, boolean receiveCancelled, Class<T> eventType, Consumer<T> consumer) {
		addListener(priority, passCancelled(receiveCancelled), eventType, consumer);
	}

	@Override
	public <T extends GenericEvent<? extends F>, F> void addGenericListener(Class<F> genericClassFilter, Consumer<T> consumer) {
		addGenericListener(genericClassFilter, EventPriority.NORMAL, consumer);
	}

	@Override
	public <T extends GenericEvent<? extends F>, F> void addGenericListener(Class<F> genericClassFilter, EventPriority priority, Consumer<T> consumer) {
		addGenericListener(genericClassFilter, priority, false, consumer);
	}

	@Override
	public <T extends GenericEvent<? extends F>, F> void addGenericListener(Class<F> genericClassFilter, EventPriority priority, boolean receiveCancelled, Consumer<T> consumer) {
		addListener(priority, passGenericFilter(genericClassFilter).and(passCancelled(receiveCancelled)), consumer);
	}

	@Override
	public <T extends GenericEvent<? extends F>, F> void addGenericListener(Class<F> genericClassFilter, EventPriority priority, boolean receiveCancelled, Class<T> eventType, Consumer<T> consumer) {
		addListener(priority, passGenericFilter(genericClassFilter).and(passCancelled(receiveCancelled)), eventType, consumer);
	}

	@SuppressWarnings("unchecked")
	private <T extends Event> void addListener(final EventPriority priority, final Predicate<? super T> filter, final Consumer<T> consumer) {
		final Class<?> clazz = TypeResolver.resolveRawArgument(Consumer.class, consumer.getClass());
		if (clazz == TypeResolver.Unknown.class) {
			throw new IllegalStateException("Failed to resolve consumer event type: " + consumer.toString());
		}

		final Class<T> eventClass = (Class<T>) clazz;
		if (Objects.equals(eventClass, Event.class))
			System.err.println("Attempting to add a Lambda listener with computed generic type of Event. " +
					"Are you sure this is what you meant? NOTE : there are complex lambda forms where " +
					"the generic type information is erased and cannot be recovered at runtime.");

		addListener(priority, filter, eventClass, consumer);
	}

	private <T extends Event> void addListener(final EventPriority priority, final Predicate<? super T> filter, final Class<T> eventClass, final Consumer<T> consumer) {
		addToListeners(consumer, eventClass, e -> doCastFilter(filter, eventClass, consumer, e), priority);
	}

	private <T extends Event> void doCastFilter(final Predicate<? super T> filter, final Class<T> eventClass, final Consumer<T> consumer, final Event e) {
		T cast = (T) e;
		if (filter.test(cast)) {
			consumer.accept(cast);
		}
	}

	private void register(Class<?> eventType, Object target, Method method) {
		try {
			final ASMEventHandler asm = new ASMEventHandler(target, method, IGenericEvent.class.isAssignableFrom(eventType));
			addToListeners(target, eventType, asm, asm.getPriority());
		} catch (Exception e) {
			System.err.println("Error registering event handler: " + eventType + " " + method);
			e.printStackTrace();
		}
	}

	private void addToListeners(final Object target, final Class<?> eventType, final IEventListener listener, final EventPriority priority) {
		ListenerList listenerList = EventListenerHelper.getListenerList(eventType);
		listenerList.register(busID, priority, listener);
		List<IEventListener> others = listeners.computeIfAbsent(target, k -> Collections.synchronizedList(new ArrayList<>()));
		others.add(listener);
	}

	public void unregister(Object object) {
		List<IEventListener> list = listeners.remove(object);
		if (list == null)
			return;
		for (IEventListener listener : list) {
			ListenerList.unregisterAll(busID, listener);
		}
	}

	public boolean post(Event event) {
		if (shutdown) return false;

		IEventListener[] listeners = event.getListenerList().getListeners(busID);
		int index = 0;
		try {
			for (; index < listeners.length; index++) {
				if (!trackPhases && Objects.equals(listeners[index].getClass(), EventPriority.class)) continue;
				listeners[index].invoke(event);
			}
		} catch (Throwable throwable) {
			exceptionHandler.handleException(this, event, listeners, index, throwable);
			throw throwable;
		}

		return event.isCancellable() && event.isCancelled();
	}

	public void shutdown() {
		System.out.println("EventBus " + busID + " shytting down");
		shutdown = true;
	}

	@Override
	public void start() {
		this.shutdown = false;
	}

	@Override
	public void handleException(EventBus bus, Event event, IEventListener[] listeners, int index, Throwable throwable) {
		System.err.println("Exception caught during firing event " + event + ":");
		throwable.printStackTrace();
		System.err.println("Index: " + index + " Listeners: ");
		for (int x = 0; x < listeners.length; x++)
			System.err.println(x + ": " + listeners[x]);
	}
}
